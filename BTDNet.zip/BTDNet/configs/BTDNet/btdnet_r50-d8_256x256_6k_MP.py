_base_ = ['../../_base_/datasets/meiwei_pcb.py',
          '../../_base_/default_runtime.py', '../../_base_/schedules/schedule_20k.py']

# model settings
norm_cfg = dict(type='SyncBN', requires_grad=True)
model = dict(
    type='BTDNet',
    pretrained='open-mmlab://resnet50_v1c',
    backbone=dict(
        type='ResNetV1c',
        depth=50,
        num_stages=4,
        out_indices=(0, 1, 2, 3),
        dilations=(1, 1, 2, 4),
        strides=(1, 2, 1, 1),
        norm_cfg=norm_cfg,
        norm_eval=False,
        style='pytorch',
        contract_dilation=True),
    structural_params=dict(
        in_channels=2048,
        in_index=3,
        channels=512,
        test_baseline=False,
        neck_type="ESRM",
        neck_cfg=dict(type="ESRM", use_mlp=True, feat_mode="ms"),
        branch_type="BE",
        fusion_type=[None, "DFS", None],
        residual_type=["Cat", None, None],
        sampler=dict(thresh=0.90, min_kept=20000, gamma=2, alpha=1, focal_type="kaiming", uncertainty_thresh=0.5),
        use_loss=[True, True, False],
        loss_weight=[1.0, 1.0, 1.0],
        use_ohem=[False, False, False],
        use_guided=False,
        use_smooth=False,
        pruning_ratio=None,
    ),
    decode_head=dict(
        type='FCNHead',
        in_channels=512,
        in_index=0,
        channels=256,
        num_convs=2,
        concat_input=True,
        dropout_ratio=0.1,
        num_classes=2,
        norm_cfg=norm_cfg,
        align_corners=False,
        loss_decode=dict(
            type='CrossEntropyLoss', use_sigmoid=False, loss_weight=1.0, avg_non_ignore=True)),
    auxiliary_head=dict(
        type='FCNHead',
        in_channels=1024,
        in_index=2,
        channels=256,
        num_convs=1,
        concat_input=False,
        dropout_ratio=0.1,
        num_classes=2,
        norm_cfg=norm_cfg,
        align_corners=False,
        loss_decode=dict(
            type='CrossEntropyLoss', use_sigmoid=False, loss_weight=0.4, avg_non_ignore=True)),
    # model training and testing settings
    train_cfg=dict(),
    test_cfg=dict(mode='whole'))

# optimizer
optimizer = dict(type='SGD', lr=0.01, momentum=0.9, weight_decay=0.0005)

# learning policy
lr_config = dict(policy='poly', power=0.9, min_lr=1e-5, by_epoch=False, warmup='linear', warmup_iters=200)

# runtime settings
runner = dict(type='IterBasedRunner', max_iters=6000)
checkpoint_config = dict(by_epoch=False, interval=20)
evaluation = dict(interval=20, metric=['mIoU', 'mDice', 'mFscore'])

log_config = dict(
    interval=10,
    hooks=[
        dict(type='TextLoggerHook', by_epoch=False),
        # dict(type='TensorboardLoggerHook')
    ])

# dataset settings
data = dict(
    samples_per_gpu=24,
    workers_per_gpu=0,
    val=dict(
        split='coco/annotations/image_info_test-dev2017.json'),
)
