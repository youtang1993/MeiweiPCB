_base_ = ['../_base_/models/fcn_r50-d8.py', '../_base_/datasets/meiwei_pcb.py',
          '../_base_/default_runtime.py', '../_base_/schedules/schedule_20k.py']

# model settings
model = dict(
    decode_head=dict(num_classes=2), auxiliary_head=dict(num_classes=2))

# optimizer
optimizer = dict(type='SGD', lr=0.01, momentum=0.9, weight_decay=0.0005)

# learning policy
lr_config = dict(policy='poly', power=0.9, min_lr=1e-5, by_epoch=False, warmup='linear', warmup_iters=200)

# runtime settings
runner = dict(type='IterBasedRunner', max_iters=4000)
checkpoint_config = dict(by_epoch=False, interval=20)
evaluation = dict(interval=20, metric=['mIoU', 'mDice', 'mFscore'])

log_config = dict(
    interval=10,
    hooks=[
        dict(type='TextLoggerHook', by_epoch=False),
        # dict(type='TensorboardLoggerHook')
    ])

# dataset settings
data = dict(
    samples_per_gpu=12,
    workers_per_gpu=0,
    val=dict(
        split='coco/annotations/image_info_test-dev2017.json'),
)
