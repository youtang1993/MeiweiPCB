# Copyright (c) OpenMMLab. All rights reserved.
import argparse
import os.path as osp
import time

import mmcv
import numpy as np
import torch
from mmcv import Config
from mmcv.parallel import MMDataParallel
from mmcv.runner import load_checkpoint, wrap_fp16_model

from mmseg.datasets import build_dataloader, build_dataset
from mmseg.models import build_segmentor


def parse_args():
    parser = argparse.ArgumentParser(description='MMSeg benchmark a model')
    parser.add_argument('config', help='test config file path')
    parser.add_argument('checkpoint', help='checkpoint file')
    parser.add_argument(
        '--log-interval', type=int, default=50, help='interval of logging')  # 打印中间输出的频率
    parser.add_argument(
        '--work-dir',
        help=('if specified, the results will be dumped '
              'into the directory as json'))
    parser.add_argument('--repeat-times', type=int, default=5)
    parser.add_argument('--dataset-repeat-times', type=int, default=1)  # 测试集的长度
    parser.add_argument('--samples-per-gpu', type=int, default=1)  # 单个GPU加载的图像个数 --> 利用并行加速
    parser.add_argument('--workers-per-gpu', type=int, default=4)  # 单个GPU加载的图像个数 --> 利用并行加速
    parser.add_argument('--benchmark', action="store_true")  # 是否使用cudnn加速
    args = parser.parse_args()
    return args


def clean(data):
    data = np.array(data)

    Q1 = np.percentile(data, 25)  # 四分位数
    Q3 = np.percentile(data, 75)
    IQR = Q3 - Q1  # 也就是箱体的长度

    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR  # 分别计算上限和下限
    data_clean = data[(data > lower_bound) & (data < upper_bound)]  # 这些数据保留

    return data_clean  # 清洗数据


def cleanRepeat(data):
    data = np.array(data)

    data_clean = clean(data)
    if len(data_clean) != len(data):
        data_clean = cleanRepeat(data_clean)  # 重复清洗直到不再出现异常值

    return data_clean


def main():
    args = parse_args()

    cfg = Config.fromfile(args.config)
    timestamp = time.strftime('%Y%m%d_%H%M%S', time.localtime())
    if args.work_dir is not None:
        mmcv.mkdir_or_exist(osp.abspath(args.work_dir))
        json_file = osp.join(args.work_dir, f'fps_{timestamp}.json')
    else:
        # use config filename as default work_dir if cfg.work_dir is None
        work_dir = osp.join('./work_dirs',
                            osp.splitext(osp.basename(args.config))[0])
        mmcv.mkdir_or_exist(osp.abspath(work_dir))
        json_file = osp.join(work_dir, f'fps_{timestamp}.json')

    repeat_times = args.repeat_times
    # set cudnn_benchmark
    torch.backends.cudnn.benchmark = args.benchmark  # Nodus: 默认为False, 可以加速inference
    cfg.model.pretrained = None
    cfg.data.test.test_mode = True

    benchmark_dict = dict(config=args.config, unit='img / s')
    overall_fps_list = []
    for time_index in range(repeat_times):  # 重复测试的次数
        print(f'Run {time_index + 1}:')

        # Nodus: 重新定义一下Dataset --> RepeatDataset(多次重复, 拓展测试集长度)
        from mmcv.utils.config import ConfigDict
        dataset_cfg = ConfigDict()
        dataset_cfg["type"] = "RepeatDataset"
        dataset_cfg["times"] = args.dataset_repeat_times
        dataset_cfg["dataset"] = cfg.data.test
        dataset = build_dataset(dataset_cfg)

        # build the dataloader
        # TODO: support multiple images per gpu (only minor changes are needed)
        data_loader = build_dataloader(
            dataset,
            samples_per_gpu=args.samples_per_gpu,  # 单次加载的图像个数 --> 通过利用并行计算可以显著提升推理速度
            workers_per_gpu=args.workers_per_gpu,  # default: cfg.data.workers_per_gpu
            dist=False,
            shuffle=False)

        # build the model and load checkpoint
        cfg.model.train_cfg = None
        model = build_segmentor(cfg.model, test_cfg=cfg.get('test_cfg'))
        fp16_cfg = cfg.get('fp16', None)
        if fp16_cfg is not None:
            wrap_fp16_model(model)
        if 'checkpoint' in args and osp.exists(args.checkpoint):
            load_checkpoint(model, args.checkpoint, map_location='cpu')

        model = MMDataParallel(model, device_ids=[0])

        model.eval()

        # the first several iterations may be very slow so skip them
        num_warmup = 2  # 10
        pure_inf_time = 0
        total_iters = len(dataset) // args.samples_per_gpu  # 测试中dataLoader加载的batch的个数

        # benchmark with 200 image and take the average
        for i, data in enumerate(data_loader):

            torch.cuda.synchronize()
            start_time = time.perf_counter()

            with torch.no_grad():
                model(return_loss=False, rescale=True, **data)

            torch.cuda.synchronize()
            elapsed = time.perf_counter() - start_time  # 不包括数据加载的时间DataLoader

            if i >= num_warmup:
                pure_inf_time += elapsed
                if (i + 1) % args.log_interval == 0:
                    fps = (i + 1 - num_warmup) / pure_inf_time * args.samples_per_gpu
                    print(f'Done image [{i + 1:<3}/ {total_iters}], '
                          f'fps: {fps:.2f} img / s')

            if (i + 1) == total_iters:
                fps = (i + 1 - num_warmup) / pure_inf_time * args.samples_per_gpu
                print(f'Overall fps: {fps:.2f} img / s\n')
                benchmark_dict[f'overall_fps_{time_index + 1}'] = round(fps, 2)
                overall_fps_list.append(fps)
                break
    benchmark_dict['average_fps'] = round(np.mean(cleanRepeat(overall_fps_list)), 2)
    benchmark_dict['fps_variance'] = round(np.var(cleanRepeat(overall_fps_list)), 4)  # 额外清洗数据
    print(f'Average fps of {repeat_times} evaluations: '
          f'{benchmark_dict["average_fps"]}')
    print(f'The variance of {repeat_times} evaluations: '
          f'{benchmark_dict["fps_variance"]}')
    mmcv.dump(benchmark_dict, json_file, indent=4)


if __name__ == '__main__':
    main()

# Nodus: 运行命令示例
# CUDA_VISIBLE_DEVICES="0" python tools/benchmark.py path-to-config path-to-model --log-interval 50 --repeat-times 30 --dataset-repeat-times 1 --samples-per-gpu 1
# CUDA_VISIBLE_DEVICES="0" python tools/benchmark.py path-to-config path-to-model --log-interval 2 --repeat-times 30 --dataset-repeat-times 5 --samples-per-gpu 100 --benchmark
