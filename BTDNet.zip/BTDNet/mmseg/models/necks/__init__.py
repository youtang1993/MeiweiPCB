# Copyright (c) OpenMMLab. All rights reserved.
from .fpn import FPN

__all__ = ['FPN']
