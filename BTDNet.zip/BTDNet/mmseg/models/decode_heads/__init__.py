# Copyright (c) OpenMMLab. All rights reserved.
from .btdnet import BTDNet
from .fcn_head import FCNHead

__all__ = ['FCNHead', 'BTDNet']
