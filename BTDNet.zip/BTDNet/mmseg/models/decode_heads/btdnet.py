import math
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from mmcv.cnn import ConvModule
from mmcv.cnn.bricks.activation import build_activation_layer
from mmcv.runner import force_fp32
from scipy.ndimage.morphology import distance_transform_edt

from mmseg.core import add_prefix, build_pixel_sampler
from mmseg.core.seg.sampler.ohem_pixel_sampler import OHEMPixelSampler
from mmseg.ops import resize
from .. import builder
from ..builder import SEGMENTORS
from ..segmentors.encoder_decoder import EncoderDecoder


@SEGMENTORS.register_module()
class BTDNet(EncoderDecoder):
    def __init__(self, structural_params, decode_head, **kwargs):
        self.structural_params = structural_params
        self.in_channels = getattr(structural_params, "in_channels", 2048)
        self.in_index = getattr(structural_params, "in_index", 3)  # 2048
        self.channels = getattr(structural_params, "channels", 512)
        self.input_transform = getattr(structural_params, "input_transform", None)

        self.branch_type = getattr(structural_params, "branch_type", "BEF")
        assert self.branch_type in ["F", "BF", "EF", "BE", "BEF"]
        self.branch_nums = len(self.branch_type)
        assert self.branch_nums in [1, 2, 3]

        self.test_baseline = getattr(structural_params, "test_baseline", False)
        if self.test_baseline:
            self.branch_type = "F"
            self.branch_nums = 1
            decode_head["in_channels"] = 2048
            decode_head["channels"] = 512
        super(BTDNet, self).__init__(decode_head=decode_head, **kwargs)

        self._init_neck_test()
        self._init_branches()
        self._init_fusion_module()
        self._init_losses()

    def _init_decode_head(self, decode_head):
        """Initialize ``decode_head``"""
        self.decode_head = builder.build_head(decode_head)
        self.align_corners = self.decode_head.align_corners
        self.num_classes = self.decode_head.num_classes
        self.ignore_index = self.decode_head.ignore_index

        self.conv_cfg = self.decode_head.conv_cfg
        self.norm_cfg = self.decode_head.norm_cfg
        self.act_cfg = self.decode_head.act_cfg
        self.dropout = self.decode_head.dropout

    def _init_neck_test(self):
        self.neck_type = getattr(self.structural_params, "neck_type", None)
        assert self.neck_type in [None, "ESRM"]

        if self.neck_type is not None and self.branch_nums != 1:
            assert self.neck_type == "ESRM"
        if self.neck_type == "ESRM":
            use_mlp, feat_mode = True, "ms"
            neck_cfg = getattr(self.structural_params, "neck_cfg", None)
            if neck_cfg is not None:
                assert isinstance(neck_cfg, dict)
                neck_type = getattr(neck_cfg, "type", None)
                assert neck_type is not None
                if neck_type == "ESRM":
                    use_mlp = getattr(neck_cfg, "use_mlp", True)
                    feat_mode = getattr(neck_cfg, "feat_mode", "ms")
            self.neck_test = ESRM(
                channels=self.in_channels, parts=self.branch_nums, use_mlp=use_mlp, use_bn=False, feat_mode=feat_mode,
                act_layer=dict(type="ReLU"), gate_layer=dict(type="Sigmoid"))
        elif self.neck_type == None:
            self.neck_test = None
        else:
            raise NotImplementedError

    def _init_branches(self):
        self.use_loss = getattr(self.structural_params, "use_loss", [True, True, False])
        assert isinstance(self.use_loss, (tuple, list))

        if "B" in self.branch_type:
            self.body_convs = nn.Sequential(
                ConvModule(
                    self.in_channels,
                    self.channels,
                    kernel_size=3,
                    padding=1,
                    conv_cfg=self.conv_cfg,
                    norm_cfg=self.norm_cfg,
                    act_cfg=self.act_cfg),
                ConvModule(
                    self.channels,
                    self.channels,
                    3,
                    padding=1,
                    conv_cfg=self.conv_cfg,
                    norm_cfg=self.norm_cfg,
                    act_cfg=self.act_cfg))
            if self.use_loss[0]:
                self.body_conv_seg = nn.Conv2d(
                    self.channels, self.num_classes, kernel_size=1)

        if "E" in self.branch_type:
            self.edge_convs = nn.Sequential(
                ConvModule(
                    self.in_channels,
                    self.channels,
                    kernel_size=3,
                    padding=1,
                    conv_cfg=self.conv_cfg,
                    norm_cfg=self.norm_cfg,
                    act_cfg=self.act_cfg),
                ConvModule(
                    self.channels,
                    self.channels,
                    3,
                    padding=1,
                    conv_cfg=self.conv_cfg,
                    norm_cfg=self.norm_cfg,
                    act_cfg=self.act_cfg))
            if self.use_loss[1]:
                self.edge_conv_seg = nn.Conv2d(
                    self.channels, 2, kernel_size=1)  # 输出2维logit(0/1)

        if "F" in self.branch_type:
            if not self.test_baseline:
                self.reduce_conv = ConvModule(
                    self.in_channels, self.channels, kernel_size=3, padding=1,
                    conv_cfg=self.conv_cfg, norm_cfg=self.norm_cfg, act_cfg=self.act_cfg
                )
            else:
                self.reduce_conv = None

    def _init_fusion_module(self):
        if self.branch_nums in [2, 3]:
            fusion_type = getattr(self.structural_params, "fusion_type", ["Cat", None, None])
            assert isinstance(fusion_type, (tuple, list))
            assert len(fusion_type) == 3
            fusion_in_type, fusion_out_type, fusion_refine_type = fusion_type

            assert fusion_in_type in [None, "Sum", "Cat"]
            assert fusion_out_type in [None, "AFSM"]
            assert fusion_refine_type in [None, "ESRM"]

            self.merge_branch = MergeBranch(
                in_type=fusion_in_type, out_type=fusion_out_type, refine_type=fusion_refine_type, channels=512,
                conv_cfg=self.conv_cfg, norm_cfg=self.norm_cfg, act_cfg=self.act_cfg)

        if self.branch_nums == 3:
            residual_type = getattr(self.structural_params, "residual_type", ["Cat", None, None])
            assert isinstance(residual_type, (tuple, list))
            assert len(residual_type) == 3
            residual_in_type, residual_out_type, residual_refine_type = residual_type

            assert residual_in_type in [None, "Sum", "Cat"]
            assert residual_out_type in [None, "AFSM"]
            assert residual_refine_type in [None, "ESRM"]

            self.merge_residual = MergeBranch(
                in_type=residual_in_type, out_type=residual_out_type, refine_type=residual_refine_type, channels=512,
                conv_cfg=self.conv_cfg, norm_cfg=self.norm_cfg, act_cfg=self.act_cfg)

    def _init_losses(self):
        self.relax_boundary_hard = RelaxedBoundaryLabel(self.num_classes, ignore_index=self.ignore_index)
        self.sampler = getattr(self.structural_params, "sampler", None)
        self.use_ohem = getattr(self.structural_params, "use_ohem", [False, False, False])
        if True in self.use_ohem:
            assert self.sampler is not None

        loss_weight = getattr(self.structural_params, "loss_weight", [1.0, 1.0, 1.0])
        assert isinstance(loss_weight, (tuple, list))

        # loss_body
        if "B" in self.branch_type and self.use_loss[0]:
            loss_ce_body = dict(type='CrossEntropyLoss', use_sigmoid=False, loss_weight=loss_weight[0])
            self.loss_ce_body = builder.build_loss(loss_ce_body)

        # loss_edge
        if "E" in self.branch_type and self.use_loss[1]:
            loss_ce_edge = dict(
                type='CrossEntropyLoss', use_sigmoid=False, loss_weight=loss_weight[1], avg_non_ignore=True)
            self.loss_ce_edge = builder.build_loss(loss_ce_edge)

        # loss_contour
        if self.use_loss[2]:
            loss_ce_contour = dict(type='CrossEntropyLoss', use_sigmoid=False, loss_weight=loss_weight[2])
            self.loss_ce_contour = builder.build_loss(loss_ce_contour)

    def _transform_inputs(self, inputs):
        if self.input_transform == 'resize_concat':
            assert isinstance(self.in_index, (list, tuple))
            inputs = [inputs[i] for i in self.in_index]
            upsampled_inputs = [
                resize(
                    input=x,
                    size=inputs[0].shape[2:],
                    mode='bilinear',
                    align_corners=self.align_corners) for x in inputs
            ]
            feat_common = torch.cat(upsampled_inputs, dim=1)
        elif self.input_transform == 'multiple_select':
            assert isinstance(self.in_index, (list, tuple))
            feat_common = [inputs[i] for i in self.in_index]
        else:
            assert isinstance(self.in_index, int)
            feat_common = inputs[self.in_index]

        assert not isinstance(feat_common, (list, tuple))

        feat_refine = self.forward_neck_test(feat_common)

        return feat_refine

    def forward_neck_test(self, feat_common):
        pruning_ratio = getattr(self.structural_params, "pruning_ratio", None)
        if isinstance(pruning_ratio, str):
            pruning_ratio = eval(pruning_ratio)
        if pruning_ratio is not None:
            pruning_ratio = float(pruning_ratio)
            assert isinstance(pruning_ratio, float)
            assert 0 <= pruning_ratio <= 1.0

        neck_test = getattr(self, "neck_test", None)
        if neck_test is not None:
            feat_refine = neck_test(feat_common, pruning_ratio)
            if isinstance(feat_refine, (list, tuple)):
                feat_refine = feat_refine[-1]
            if feat_refine.dim() == 5:
                assert feat_refine.size(1) == self.branch_nums  # (N, parts, C, H, W)
                feat_refine = list(feat_refine.permute(1, 0, 2, 3, 4))
            else:
                feat_refine = [feat_refine]

        else:
            feat_refine = [feat_common] * self.branch_nums

        assert self.branch_nums == len(feat_refine)

        return feat_refine

    def forward_fusion(self, feat_body, feat_edge, feat_common):
        feat_list = [feat for feat in [feat_body, feat_edge, feat_common] if feat is not None]
        if len(feat_list) == 1:
            assert feat_common is not None
            feat_fusion = feat_common
        else:
            feat_fusion = self.merge_branch(*feat_list[:2])

            if len(feat_list) == 3:
                feat_fusion = self.merge_residual(feat_fusion, feat_list[2])

        return feat_fusion

    def body_cls_seg(self, feat):
        # body feature classification
        if self.dropout is not None:
            feat = self.dropout(feat)
        output = self.body_conv_seg(feat)
        return output

    def edge_cls_seg(self, feat):
        # edge feature classification
        if self.dropout is not None:
            feat = self.dropout(feat)
        output = self.edge_conv_seg(feat)
        return output

    def forward_btd_head(self, feat_refine):
        # branch_type, "BF", "EF", "BE"
        if self.branch_type == "F":
            feat_common = feat_refine[0]
            feat_body, feat_edge = None, None
        elif self.branch_type == "BF":
            feat_body, feat_common = feat_refine  # BF
            feat_edge = None
        elif self.branch_type == "EF":
            feat_edge, feat_common = feat_refine  # EF
            feat_body = None
        elif self.branch_type == "BE":
            feat_body, feat_edge = feat_refine  # BE
            feat_common = None
        elif self.branch_type == "BEF":
            feat_body, feat_edge, feat_common = feat_refine  # BEF
        else:
            raise NotImplementedError

        seg_logit_body = None
        if feat_body is not None:
            feat_body = self.body_convs(feat_body)
            if self.use_loss[0]:
                seg_logit_body = self.body_cls_seg(feat_body)

        seg_logit_edge = None
        if feat_edge is not None:
            feat_edge = self.edge_convs(feat_edge)
            if self.use_loss[1]:
                seg_logit_edge = self.edge_cls_seg(feat_edge)

        if feat_common is not None:
            if self.reduce_conv is not None:
                feat_common = self.reduce_conv(feat_common)
            else:
                assert self.test_baseline

        feat_fusion = self.forward_fusion(feat_body, feat_edge, feat_common)
        seg_logit_fusion = self.decode_head.forward([feat_fusion])

        return seg_logit_body, seg_logit_edge, seg_logit_fusion

    def get_uncertainty_area(self, seg_logit, seg_label, use_topk=False, topk=3):
        """Sample pixels that have high loss or with low prediction confidence.

        Args:
            seg_logit (torch.Tensor): segmentation logits, shape (N, C, H, W)
            seg_label (torch.Tensor): segmentation label, shape (N, 1, H, W)

        Returns:
            torch.Tensor: segmentation weight, shape (N, H, W)
        """

        assert self.sampler is not None

        thresh = self.sampler["thresh"]
        min_kept = self.sampler["min_kept"]  # for OHEMSampler
        assert thresh is not None

        gamma = self.sampler["gamma"]
        alpha = self.sampler["alpha"]
        focal_type = self.sampler["focal_type"]  # for FocalWeightSampler
        assert focal_type in ["kaiming", "entropybased", "OHEM"]

        uncertainty_thresh = self.sampler["uncertainty_thresh"]  # 0.5

        with torch.no_grad():
            assert seg_label.dim() == 4
            assert seg_logit.size(1) != 1
            if seg_label.size(1) == 1:
                # (N, C, H, W) + (N, 1, H, W)
                ohem_sampler = build_pixel_sampler(
                    dict(type="OHEMPixelSampler", thresh=thresh, min_kept=min_kept),
                    context=self.decode_head)
            else:
                # (N, C, H, W) + (N, C, H, W)
                assert seg_logit.shape == seg_label.shape
                ohem_sampler = OHEMReimplement(context=self.decode_head, thresh=thresh, min_kept=min_kept)

            seg_logit = resize(
                input=seg_logit, size=seg_label.shape[-2:], mode='bilinear', align_corners=self.align_corners)  # resize
            valid_seg_weight = ohem_sampler.sample(seg_logit, seg_label.clone())  # (N, H, W)

            if focal_type == "kaiming":
                seg_label_tmp = seg_label.clone()
                if seg_label.size(1) == 1:
                    seg_label_tmp[seg_label_tmp == self.ignore_index] = 0
                    pred = seg_logit.softmax(dim=1).gather(dim=1, index=seg_label_tmp).squeeze(dim=1)  # (N, H, W)
                else:
                    pred = seg_logit.softmax(dim=1) * seg_label_tmp
                    pred = pred.sum(dim=1)
                uncertainty = 1.0 - pred
                focal_weight = alpha * uncertainty.pow(gamma)

            elif focal_type == "entropybased":
                probs = seg_logit.softmax(dim=1)  # (N, C, H, W)
                if use_topk:
                    assert self.decode_head.num_classes == seg_logit.size(1)  # num_classes
                    assert topk in range(2, seg_logit.size(1) + 1)
                    probs = probs.topk(k=self.topk, dim=1)[0]  # (N, C, H, W) --> (N, topk, H, W), 获取topk
                    probs = probs / probs.sum(dim=1, keepdim=True)

                entropy = (- probs * probs.log()).sum(dim=1, keepdim=True)
                uncertainty = entropy / torch.tensor(probs.size(1)).float().log()
                uncertainty = uncertainty.squeeze(dim=1)
                focal_weight = alpha * uncertainty.pow(gamma)

            elif focal_type == "OHEM":
                focal_weight = 1.0

            else:
                raise NotImplementedError

            seg_weight = focal_weight * valid_seg_weight
            if seg_label.size(1) == 1:
                ignore_mask = seg_label.squeeze(dim=1) == self.ignore_index  # class_index, one-hot, (N, H, W)
            else:
                ignore_mask = seg_label.sum(dim=1) == 0  # multi-hot, (N, H, W)

            uncertainty_mask = uncertainty.ge(uncertainty_thresh) * valid_seg_weight
            uncertainty_mask = uncertainty_mask + self.ignore_index * ignore_mask
            uncertainty_mask = uncertainty_mask.long()  # uncertainty_mask, int64, 0/1, (N, H, W)

            return seg_weight, uncertainty_mask  # (N, H, W), (N, H, W)

    @force_fp32(apply_to=('seg_logits',))
    def btd_head_losses(self, seg_logits, img_metas, gt_semantic_seg, train_cfg):
        """
        seg_logits, (N, C, H, W); gt_semantic_seg, (N, 1, H, W);
        multi_hot_label, (N, num_classes, H, W); boundary_mask, (N, H, W)

        """

        multi_hot_label, boundary_mask = self.relax_boundary_hard(gt_semantic_seg, radius=5, cal_type="edt")
        seg_logit_body, seg_logit_edge, seg_logit_fusion = seg_logits

        # step1, branch_body, CE Loss + Relaxing Boundary
        losses = dict()
        if seg_logit_body is not None:
            seg_logit_body = resize(
                input=seg_logit_body,
                size=gt_semantic_seg.shape[2:],
                mode='bilinear', align_corners=self.align_corners)

            if self.use_ohem[0]:
                # (N, H, W), (N, H, W)
                seg_weight_body, uncertainty_mask_body = self.get_uncertainty_area(seg_logit_body, multi_hot_label)
            else:
                seg_weight_body = None
            avg_factor_body = (gt_semantic_seg != self.ignore_index).sum()  # avg_non_ignore

            # relaxing loss
            loss_ce_body = self.loss_ce_body(
                seg_logit_body,
                multi_hot_label.float(),
                weight=seg_weight_body,
                avg_factor=avg_factor_body,
            )
            loss_ce_body = {self.loss_ce_body.loss_name: loss_ce_body}  # dict
            losses.update(add_prefix(loss_ce_body, 'L_body'))

        # step2, branch_edge
        if seg_logit_edge is not None:
            seg_logit_edge = resize(
                input=seg_logit_edge,
                size=gt_semantic_seg.shape[2:],
                mode='bilinear', align_corners=self.align_corners)

            if self.use_ohem[1] and (not self.loss_ce_edge.use_sigmoid):
                boundary_mask_gt = boundary_mask.unsqueeze(dim=1)  # --> (N, 1, H, W)
                seg_weight_edge, uncertainty_mask_edge = self.get_uncertainty_area(seg_logit_edge, boundary_mask_gt)
            else:
                seg_weight_edge = None

            loss_ce_edge = self.loss_ce_edge(
                seg_logit_edge,  # (N, 2, H, W)
                boundary_mask,  # (N, H, W), class_index
                weight=seg_weight_edge,
                avg_factor=None,
                ignore_index=self.ignore_index
            )
            loss_ce_edge = {self.loss_ce_edge.loss_name: loss_ce_edge}  # dict
            losses.update(add_prefix(loss_ce_edge, 'L_edge'))

        # step3, branch_fusion
        assert seg_logit_fusion is not None
        seg_logit_fusion = resize(
            input=seg_logit_fusion,
            size=gt_semantic_seg.shape[2:],
            mode='bilinear', align_corners=self.align_corners)

        if self.use_ohem[2]:
            seg_weight_fuion, uncertainty_mask_fuion = self.get_uncertainty_area(seg_logit_fusion, gt_semantic_seg)

            # seg_weight_fusion = (seg_weight_body + seg_weight_edge) / 2.0  # by default
            # uncertainty_mask_fusion = ((uncertainty_mask_body + uncertainty_mask_edge) / 2.0).bool().long()
        else:
            seg_weight_fuion = None

        loss_ce_fusion = self.decode_head.losses(
            seg_logit_fusion, gt_semantic_seg, seg_weight=seg_weight_fuion)  # dict
        if self.branch_nums == 1:
            losses.update(loss_ce_fusion)
        else:
            losses.update(add_prefix(loss_ce_fusion, 'L_fusion'))

        # step4, branch_fusion
        if self.use_loss[2]:
            boundary_mask_tmp = boundary_mask.clone()
            boundary_mask_tmp[boundary_mask_tmp == self.ignore_index] = 0
            seg_weight_contour = boundary_mask_tmp.float()
            avg_factor_contour = seg_weight_contour.sum()

            loss_ce_contour = self.loss_ce_contour(
                seg_logit_fusion,
                gt_semantic_seg.clone().squeeze(dim=1),  # (N, H, W)
                weight=seg_weight_contour,
                avg_factor=avg_factor_contour,
                ignore_index=self.ignore_index
            )
            loss_ce_contour = {self.loss_ce_contour.loss_name: loss_ce_contour}  # dict
            losses.update(add_prefix(loss_ce_contour, 'L_contour'))

        return losses

    def post_processing(self, seg_logits, img_metas, test_cfg):
        seg_logit_body, seg_logit_edge, seg_logit_fusion = seg_logits  # tuple, body+edge+fusion

        if isinstance(seg_logit_fusion, (tuple, list)):
            seg_logit = seg_logit_fusion[0]
        else:
            seg_logit = seg_logit_fusion

        return seg_logit

    def _decode_head_forward_train(self, x, img_metas, gt_semantic_seg):
        """Run forward function and calculate loss for decode head in training."""

        feat_refine = self._transform_inputs(x)
        seg_logits = self.forward_btd_head(feat_refine)  # logit_body, logit_edge, logit_fusion

        losses = dict()
        loss_decode = self.btd_head_losses(seg_logits, img_metas, gt_semantic_seg, self.train_cfg)
        losses.update(add_prefix(loss_decode, 'decode'))

        return losses

    def _decode_head_forward_test(self, x, img_metas):
        """Run forward function and calculate loss for decode head in inference."""

        feat_refine = self._transform_inputs(x)  # list, parts[(N,C,H,W)]
        seg_logits = self.forward_btd_head(feat_refine)  # logit_body, logit_edge, logit_fusion

        seg_logit = self.post_processing(seg_logits, img_metas, self.test_cfg)

        # self.vis_uncertainty_distance(seg_logit, img_metas)

        return seg_logit


class RelaxedBoundaryLabel(nn.Module):
    def __init__(self, num_classes, ignore_index=255):
        super(RelaxedBoundaryLabel, self).__init__()

        self.num_classes = num_classes
        self.ignore_index = ignore_index

    def forward_edt(self, seg_label, radius):
        """
        Converts a segmentation mask (N,1,H,W) to a binary edgemap (N,H,W)

        """

        assert radius >= 0

        seg_logit_onehot = F.one_hot(seg_label.clone().long(), self.num_classes)  # (N, 1, H, W, num_classes)
        seg_logit_onehot = seg_logit_onehot.squeeze(dim=1).permute(0, 3, 1, 2).contiguous()  # (N, num_classes, H, W)
        seg_logit_onehot_slice = seg_logit_onehot.view(-1, *seg_logit_onehot.shape[-2:]).cpu()  # 切片slice

        # We need to pad the borders for boundary conditions
        # seg_logit_onehot = F.pad(seg_logit_onehot, [1, 1, 1, 1], mode="constant", value=0)

        proc = lambda seg_logit_onehot_index: \
            distance_transform_edt(seg_logit_onehot_index) + distance_transform_edt(1.0 - seg_logit_onehot_index)
        dist = map(proc, seg_logit_onehot_slice)  # N*num_classes
        dist = torch.tensor(np.stack(list(dist), axis=0)).to(seg_label.device)  # (N*num_classes, H, W)
        dist = dist.view(-1, self.num_classes, *dist.shape[-2:])  # (N, num_classes, H, W)

        dist[dist > radius] = 0.0

        # (N, num_classes, H, W), int64, 0/1
        multi_hot_label_boundary = dist.bool().long()  # (N, num_classes, H, W)

        multi_hot_label = multi_hot_label_boundary + seg_logit_onehot
        multi_hot_label = multi_hot_label.bool().long()

        boundary_mask = multi_hot_label_boundary.sum(dim=1, keepdim=True)
        boundary_mask = boundary_mask.bool().long()  # (N, 1, H, W), int64, 0/1

        return multi_hot_label, boundary_mask

    def forward(self, seg_label, radius, cal_type="edt"):
        # seg_label, class_index
        ignore_mask = seg_label == self.ignore_index  # bool, ignore_mask

        tmp_seg_label = seg_label.clone()
        tmp_seg_label[ignore_mask] = 0

        if cal_type == "edt":
            multi_hot_label, boundary_mask = self.forward_edt(tmp_seg_label, radius=radius)
        else:
            raise NotImplementedError

        valid_mask = ~ ignore_mask  # (N, 1, H, W), bool
        multi_hot_label = multi_hot_label * valid_mask  # (N, num_classes, H, W), long, int64
        boundary_mask = boundary_mask * valid_mask + self.ignore_index * ignore_mask
        boundary_mask = boundary_mask.long()  # (N, 1, H, W), long, int64

        return multi_hot_label, boundary_mask.squeeze(dim=1)

class OHEMReimplement(OHEMPixelSampler):

    def sample(self, seg_logit, seg_label_multihot):

        with torch.no_grad():
            assert seg_logit.shape == seg_label_multihot.shape  # (N, num_classes, H, W)
            assert seg_label_multihot.shape[1] == self.context.num_classes

            batch_kept = self.min_kept * seg_label_multihot.size(0)
            seg_weight = seg_logit.new_zeros(
                size=(seg_logit.size(0), seg_logit.size(2), seg_logit.size(2)))  # (N, H, W)
            if self.thresh is not None:
                seg_prob = F.softmax(seg_logit, dim=1) * seg_label_multihot
                seg_prob = seg_prob.sum(dim=1)  # (N, H, W)

                valid_mask = seg_prob != 0
                sort_prob, sort_indices = seg_prob[valid_mask].sort()

                if sort_prob.numel() > 0:
                    min_threshold = sort_prob[min(batch_kept, sort_prob.numel() - 1)]
                else:
                    min_threshold = 0.0
                threshold = max(min_threshold, self.thresh)

                valid_seg_weight = seg_weight[valid_mask]
                valid_seg_weight[seg_prob[valid_mask] < threshold] = 1.

                seg_weight[valid_mask] = valid_seg_weight

            return seg_weight


class MergeBranch(nn.Module):
    def __init__(self, in_type="Cat", out_type=None, refine_type=None, channels=512,
                 conv_cfg=None, norm_cfg=None, act_cfg=None):
        super(MergeBranch, self).__init__()
        assert in_type in [None, "Sum", "Cat"]
        assert out_type in [None, "AFSM"]
        assert refine_type in [None, "ESRM"]

        self.in_type = in_type
        self.out_type = out_type
        self.refine_type = refine_type
        self.channels = channels
        self.conv_cfg, self.norm_cfg, self.act_cfg = conv_cfg, norm_cfg, act_cfg

        self._init_in_module()
        self._init_out_module()
        self._init_refine_module()

    def _init_in_module(self):
        if self.in_type == "Cat":
            self.in_conv = ConvModule(
                self.channels * 2,
                self.channels,
                3,
                padding=1,
                conv_cfg=self.conv_cfg,
                norm_cfg=self.norm_cfg,
                act_cfg=self.act_cfg)  # 1024 --> 512

    def _init_out_module(self):
        if self.out_type == "AFSM":
            assert self.in_type is None
            self.fusion_conv = AFSM(
                channels=self.channels, conv_cfg=self.conv_cfg, norm_cfg=self.norm_cfg, act_cfg=self.act_cfg)
        elif self.out_type is None:
            assert self.in_type is not None  # sum/cat
            pass
        else:
            raise NotImplementedError

    def _init_refine_module(self):

        if self.refine_type == "ESRM":
            self.refine_conv = ESRM(
                channels=self.channels, parts=1, use_mlp=True, use_bn=False, feat_mode="ms",
                act_layer=dict(type="ReLU"), gate_layer=dict(type="Sigmoid"))
        else:
            raise NotImplementedError

    def forward(self, feat_1, feat_2):
        assert feat_1.shape == feat_2.shape

        # input
        if self.in_type == "Sum":
            feat_in = feat_1 + feat_2
        elif self.in_type == "Cat":
            feat_in = torch.cat([feat_1, feat_2], dim=1)  # 1024
            feat_in = self.in_conv(feat_in)  # 1024 --> 512
        else:
            feat_in = None

        # output
        if self.out_type is None:
            assert feat_in is not None
            feat_out = feat_in
        elif self.out_type in ["AFSM"]:
            feat_out = self.fusion_conv(feat_1, feat_2)
        else:
            raise NotImplementedError

        # refine
        if self.refine_type is not None:
            feat_refine = self.refine_conv(feat_out)
        else:
            feat_refine = feat_out

        return feat_refine


class ESRM(nn.Module):
    def __init__(self, channels=None, kernel_size=3, gamma=2, beta=1, parts=1, use_mlp=True, use_bn=False,
                 feat_mode="ms", act_layer=dict(type="ReLU"), gate_layer=dict(type="Sigmoid")):
        super(ESRM, self).__init__()
        self.parts = parts

        self.feat_mode = feat_mode  # [mean, std, amax] --> m/ms/ma/msa
        assert self.feat_mode in ["m", "s", "a", "ms", "ma", "msa"]
        self.feat_nums = len(self.feat_mode)
        assert self.feat_nums in [1, 2, 3]

        if channels is not None:
            t = int(abs(math.log(channels, 2) + beta) / gamma)
            kernel_size = max(t if t % 2 else t + 1, 3)
        has_act = act_layer is not None
        assert kernel_size % 2 == 1

        # PyTorch circular padding mode is buggy as of pytorch 1.4
        # see https://github.com/pytorch/pytorch/pull/17240
        # implement manual circular padding
        self.padding = (kernel_size - 1) // 2
        if use_mlp:
            self.conv = nn.Conv1d(
                self.feat_nums, 256, kernel_size=1, padding=0, bias=True)
            self.act = build_activation_layer(act_layer)
            self.conv2 = nn.Conv1d(256, self.parts * 2, kernel_size=kernel_size, padding=0, bias=True)
        else:
            self.conv = nn.Conv1d(
                self.feat_nums, self.parts * 2, kernel_size=kernel_size, padding=0, bias=has_act)
            self.act = None
            self.conv2 = None
        if use_bn:
            self.bn = nn.BatchNorm1d(self.parts * channels * 2)
        else:
            self.bn = None
        self.gate = build_activation_layer(gate_layer)

    def forward(self, x, pruning_ratio=None):
        # Style pooling
        x_style = list()
        if "m" in self.feat_mode:
            x_mean = x.mean(dim=(2, 3))  # (N, C)
            x_style.append(x_mean)
        if "s" in self.feat_mode:
            x_std = x.std(dim=(2, 3))  # (N, C)
            x_style.append(x_std)
        if "a" in self.feat_mode:
            x_max = x.amax(dim=(2, 3))  # (N, C)
            x_style.append(x_max)
        assert x_style

        x_style = torch.stack(x_style, dim=1)  # (N, feat_nums, C)
        assert x_style.size(1) == self.feat_nums

        if self.conv2 is not None:
            y = self.conv(x_style)  # (N, 2, C) --> (N, 256, C)
            y = self.act(y)

            # Manually implement circular padding, F.pad does not seemed to be bugged
            y = F.pad(y, (self.padding, self.padding), mode='circular')
            y = self.conv2(y)  # (N, 256, C) --> (N, parts * 2, C)

        else:
            # Manually implement circular padding, F.pad does not seemed to be bugged
            y = F.pad(x_style, (self.padding, self.padding), mode='circular')
            y = self.conv(y)  # (N, 2, C) --> (N, parts * 2, C)

        y = y.view(y.size(0), -1, 1)  # (N, parts*2*C, 1)
        if self.bn is not None:
            y = self.bn(y)
        y = y.view(y.size(0), 2, self.parts, -1)  # (N, 2, parts, C)

        y_act = self.gate(y)
        w_mean = y_act[:, 0]  # (N, parts, C), miu
        w_std = y_act[:, 1]  # (N, parts, C), sigma

        if (not self.training) and (pruning_ratio is not None):
            assert self.parts == 1
            assert isinstance(pruning_ratio, (int, float))  # pruning_ratio, 0~1
            metric = w_std.detach()
            drop_index = metric <= metric.quantile(pruning_ratio, dim=-1)
            w_mean[drop_index] = 0.0
            w_std[drop_index] = 0.0

        x_mean = x.mean(dim=(2, 3)).unsqueeze(dim=1)  # (N, 1, C)
        x_std = x.std(dim=(2, 3)).unsqueeze(dim=1)  # (N, 1, C)
        y_mean = w_mean * x_mean
        y_std = w_std * x_std  # (N, parts, C) * (N, 1, C) --> (N, parts, C)

        x_norm = F.instance_norm(x).unsqueeze(dim=1)  # (N, 1, C, H, W)
        y_o = x_norm * y_std.view(*y_std.shape, 1, 1) + y_mean.view(*y_mean.shape, 1, 1)  # (N, parts, C, H, W)

        return y_act, y_o


class AFSM(nn.Module):

    def __init__(self, channels=512, conv_cfg=None, norm_cfg=None, act_cfg=None):
        super(AFSM, self).__init__()
        self.channels = channels
        self.conv_cfg, self.norm_cfg, self.act_cfg = conv_cfg, norm_cfg, act_cfg

        self.fusion_conv = ConvModule(
            self.channels * 2,
            self.channels,
            kernel_size=1,
            stride=1,
            padding=0,
            groups=self.channels,
            conv_cfg=self.conv_cfg,
            norm_cfg=self.norm_cfg,
            act_cfg=self.act_cfg)

    def forward(self, feat_body, feat_edge):
        assert feat_body.shape == feat_edge.shape  # (N, 512, H, W)

        feat_in = torch.stack([feat_body, feat_edge], dim=2)  # (N, 512, 2, H, W)
        feat_in = feat_in.view(feat_in.size(0), -1, *feat_in.shape[-2:])  # (N, 512 * 2, H, W)
        feat_out = self.fusion_conv(feat_in)  # conv-bn-relu

        return feat_out
