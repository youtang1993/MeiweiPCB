import os.path as osp

import numpy as np
from mmcv.utils import print_log
from pycocotools.coco import COCO

from mmseg.utils import get_root_logger
from .builder import DATASETS
from .custom import CustomDataset


@DATASETS.register_module()
class MeiweiPCB(CustomDataset):
    """Pascal VOC dataset.

    Args:
        split (str): Split txt file for Pascal VOC.
    """

    CLASSES = ('background', 'defect')

    PALETTE = [[0, 0, 0], [128, 0, 0], ]

    def __init__(self, split, **kwargs):
        super(MeiweiPCB, self).__init__(split=split, **kwargs)
        assert osp.exists(self.img_dir) and self.split is not None

    def load_annotations(self, img_dir, img_suffix, ann_dir, seg_map_suffix,
                         split):
        """Load annotation from directory.

        Args:
            img_dir (str): Path to image directory
            img_suffix (str): Suffix of images.
            ann_dir (str|None): Path to annotation directory.
            seg_map_suffix (str|None): Suffix of segmentation maps.
            split (str|None): Split txt file. If split is specified, only file
                with suffix in the splits will be loaded. Otherwise, all images
                in img_dir/ann_dir will be loaded. Default: None

        Returns:
            list[dict]: All image info of dataset.
        """

        img_infos = []
        if split is not None:
            coco = COCO(split)
            for img_id, img in coco.imgs.items():
                img_info = dict(filename=img["file_name"])
                if ann_dir is not None:
                    img_info['ann'] = dict(seg_map=img["file_name"].replace("jpg", "png"))

                if osp.exists(osp.join(self.ann_dir, img_info['ann']["seg_map"])):
                    img_infos.append(img_info)
        else:
            raise NotImplemented

        print_log(f'Loaded {len(img_infos)} images', logger=get_root_logger())
        return img_infos

    def prepare_train_img(self, idx):
        """Get training data and annotations after pipeline.

        Args:
            idx (int): Index of data.

        Returns:
            dict: Training data and annotation after pipeline with new keys
                introduced by pipeline.
        """

        img_info = self.img_infos[idx]
        ann_info = self.get_ann_info(idx)
        results = dict(img_info=img_info, ann_info=ann_info)
        self.pre_pipeline(results)

        results = self.pipeline(results)

        return results

    def prepare_test_img(self, idx):
        """Get testing data after pipeline.

        Args:
            idx (int): Index of data.

        Returns:
            dict: Testing data after pipeline with new keys intorduced by
                piepline.
        """
        img_info = self.img_infos[idx]
        results = dict(img_info=img_info)
        self.pre_pipeline(results)

        results = self.pipeline(results)

        return results
