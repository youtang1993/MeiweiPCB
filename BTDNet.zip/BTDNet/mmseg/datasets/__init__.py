# Copyright (c) OpenMMLab. All rights reserved.
from .meiwei_pcb import MeiweiPCB

__all__ = ['MeiweiPCB']
