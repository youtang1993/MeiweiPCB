from mmcv.runner.optimizer import OPTIMIZER_BUILDERS, OPTIMIZERS
from mmcv.runner.optimizer.default_constructor import DefaultOptimizerConstructor
from mmcv.utils import build_from_cfg


@OPTIMIZER_BUILDERS.register_module()
class MyOptimizerConstructor(DefaultOptimizerConstructor):

    def __init__(self, optimizer_cfg, paramwise_cfg=None):
        super(MyOptimizerConstructor, self).__init__(optimizer_cfg, paramwise_cfg=None)

    def __call__(self, model):
        if hasattr(model, 'module'):
            model = model.module

        optimizer_cfg = self.optimizer_cfg.copy()
        # if no paramwise option is specified, just use the global setting
        if not self.paramwise_cfg:
            optimizer_cfg['params'] = filter(lambda p: p.requires_grad, model.parameters())  # Nodus: 固定/冻结部分模型参数
            return build_from_cfg(optimizer_cfg, OPTIMIZERS)

        # set param-wise lr and weight decay recursively
        params = []
        self.add_params(params, model)
        optimizer_cfg['params'] = filter(lambda p: p.requires_grad, params)  # Nodus: 固定/冻结部分模型参数

        return build_from_cfg(optimizer_cfg, OPTIMIZERS)
